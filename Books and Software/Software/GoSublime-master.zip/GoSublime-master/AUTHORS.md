This is the official list of GoSublime authors for copyright purposes.

* Alexey "AlekSi" Palazhchenko https://github.com/AlekSi
* Cameron Walters https://github.com/cee-dub
* Christoph Hack https://github.com/tux21b
* Dave Brophy https://github.com/davelondon
* dersebi https://github.com/dersebi
* DisposaBoy https://github.com/DisposaBoy
* Geert-Johan Riemer https://github.com/GeertJohan
* guillermooo https://github.com/guillermooo
* igm https://github.com/igm
* John Asmuth https://github.com/skelterjohn
* teejae https://github.com/teejae
* eddie cianci https://github.com/defeated
