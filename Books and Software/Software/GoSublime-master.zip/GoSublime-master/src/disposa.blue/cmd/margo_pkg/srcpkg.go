// +build !go1.4

package margo_pkg

import (
	"path/filepath"
)

const SrcPkg = "src" + string(filepath.Separator) + "pkg"
