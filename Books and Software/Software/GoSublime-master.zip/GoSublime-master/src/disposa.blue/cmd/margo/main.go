package main

import (
	"disposa.blue/cmd/margo_pkg"
)

func main() {
	margo_pkg.Main()
}
